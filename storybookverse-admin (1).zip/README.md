# StoryBookVerse Admin Version

Includes:
- Homepage
- Login page
- Dashboard
- Stories page
- Basic Admin Panel
- Comment moderation UI

Admin page:
`/admin`

## Deploy
Upload to GitHub and deploy with Vercel.